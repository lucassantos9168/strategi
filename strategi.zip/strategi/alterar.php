<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title> Stramoveis </title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="assets/css/estilo.css" media="screen" />
    <link rel="icon" href="assets/imagens/favicon.ico">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Courgette&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
  </head>
  <body style="height: 0px;">
   
    <div class="box">
      
      <div class="area">
        Alterar dados
      </div> <br>

      <img src="assets/imagens/alterar1.png"> <br> <br> <br>
      <?php  include('bd/cliente.php'); ?>
      <?php
        if (isset($_GET['editar'])) { // insere o valor do cpf do cliente desejado no input //
            $cpf = $_GET['editar'];

            $c = new cliente();
            $cliente = $c->consulta($cpf);

        }
      ?>
      <form action="" method="post">
        <input type="text" id="cpf" name="cpf" required="" value="<?php echo $cpf ?>" pattern="\d{3}\.\d{3}\.\d{3}-\d{2}">
        <input type="text" id="email" name="email" required="" placeholder="E-mail" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$">
        <input type="text" id="tel" name="tel" required="" placeholder="Telefone (ex: (xx) xxxxx-xxxx)" pattern="\([0-9]{2}\)[\s][0-9]{5}-[0-9]{4}"> <br> <br>
        <button type="submit" name="altera" id="altera"> Alterar </button> <br>
      

        <?php
            if (isset($_POST['altera'])) { // modifica os dados do cliente //
                $tel = $_POST['tel'];
                $cpf = $_POST['cpf'];
                $email = $_POST['email'];

                $f = new cliente();
                $f->altera($tel, $cpf, $email);

                header("location: gerenciamentocliente.php");
            }
        ?>

      </form>

      <a href="gerenciamentocliente.php"> <button> Voltar </button>  </a>
      
    </div>

  </body>
</html>