<?php

include_once('conexao.php');

class cliente { // classe cliente //
    private $nome;
    private $email;
    private $cpf;
    private $tel;
    

    function getnome() {
        return $this->nome;
    }
    
    function getcpf() {
        return $this->cpf;
    }
    
    function getemail() {
        return $this->email;
    }
    
    function gettel() {
        return $this->tel;
    }
    
    
    function setnome($nome) {
        $this->nome = $nome;
    }
    function setcpf($cpf) {
        $this->cpf = $cpf;
    }

    function setemail($email) {
        $this->email = $email;
    }   
    
    function settel ($tel) {
        $this->tel = $tel;
    }


    function __construct($nome = null, $cpf = null, $email = null, $tel = null) {
        $this->nome = $nome;
        $this->cpf = $cpf;
        $this->email = $email;
        $this->tel = $tel;
    }

    public function insere($nome, $cpf, $email, $tel){ //método insere para cadastro //
      try {
        $sql = "INSERT INTO tbcliente(nome, cpf, email, tel)
                VALUES (?, ?, ?, ?)";
        $conn = ConexaoBD::conecta();

        $stm  = $conn->prepare($sql);
        $stm->bindParam(1, $nome);
        $stm->bindParam(2, $cpf);
        $stm->bindParam(3, $email);
        $stm->bindParam(4, $tel);
        
	$stm->execute();
        return 1;
      } catch (Exception $e) {
        return 0;
      }
    }
    
    public function lista(){ //método de listagem //
        try {
            $sql  = "SELECT nome, cpf, email, tel FROM tbcliente ORDER BY nome";
            $conn = ConexaoBD::conecta();
            $sql  = $conn->query($sql);
            $res = array();
            while($row = $sql->fetch(PDO::FETCH_OBJ)) {
                $cliente = new cliente();
                $cliente->setnome($row->nome);
                $cliente->setcpf($row->cpf);
                $cliente->setemail($row->email);
                $cliente->settel($row->tel);
                $res[] = $cliente;
            }
            return $res;
        } catch (Exception $e) {
             echo "ERRO: ".$e->getMessage()."<br><br>";
        }
    }
    
    public function exclui($codigo){ //método de exclusão //
      try {
	      $sql = "DELETE FROM tbcliente WHERE cpf = ?";
	      $conn = ConexaoBD::conecta();

	      $stm = $conn->prepare($sql);
	      $stm->bindParam(1, $codigo);
	      $stm->execute();
              return 1;
	    } catch (Exception $e) {
              return 0;
      } //try-catch
    } //método exclui
    
    public function altera($tel, $email, $codigo){ //método de alterar dados //
        try {
            $sql = "UPDATE tbcliente
                       SET tel = ?, email = ?
                     WHERE cpf = ?";
            $conn = ConexaoBD::conecta();

            $stm = $conn->prepare($sql);
            $stm->bindParam(1, $tel);
            $stm->bindParam(2, $codigo);
            $stm->bindParam(3, $email);
            $stm->execute();
            return 1;
	} catch (Exception $e) {
            return 0;
        } //try-catch
    } //método altera
    
    public function consulta($cpf){ //método para consulta de cpf //
        try {
            $sql  = "SELECT cpf, nome FROM tbcliente WHERE cpf=".$cpf." ORDER BY cpf";
            $conn = ConexaoBD::conecta();
            $sql  = $conn->query($sql);

            $res = array();
            while($row = $sql->fetch(PDO::FETCH_OBJ)) {
                $cliente = new cliente();
                $cliente->setcpf($row->cpf);
                $cliente->setnome($row->nome);

                $res[] = $cliente;
            }
            return $res;
        } catch (Exception $e) {
             return "ERRO: ".$e->getMessage()."<br><br>";
        }
    }
}
