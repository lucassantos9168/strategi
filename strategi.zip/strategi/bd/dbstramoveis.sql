SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE dbstramoveis;

USE dbstramoveis;

CREATE TABLE `tbcorretor` (
  `idcorretor` int(11),
  `usuario` varchar(255),
  `senha` varchar(255)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `tbcliente` (
  `nome` varchar(255),
  `cpf` varchar(255),
  `email` varchar(255),
  `tel` varchar(255)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `tbvenda` (
  `idvenda` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `noimovel` varchar(255),
  `endereco` varchar(255),
  `valor` decimal(7,3),
  `valorcomissao` decimal(7,3)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbcorretor` (`idcorretor`, `usuario`, `senha`) VALUES
(1, 'Lucas', 'strategi');

INSERT INTO `tbvenda` (`noimovel`, `endereco`, `valor`, `valorcomissao` ) VALUES
('Strapartment', 'R. São Lucas, Tirol, Natal - RN', '450.000', '22.500');

INSERT INTO `tbvenda` (`noimovel`, `endereco`, `valor`, `valorcomissao` ) VALUES
('Strahouse', 'R. São Jorge, Ribeira, Natal - RN', '200.000', '10.000');

ALTER TABLE `tbcorretor`
  ADD PRIMARY KEY (`idcorretor`);

ALTER TABLE `tbcliente`
  ADD PRIMARY KEY (`cpf`);

