<?php

include_once('conexao.php');

class imovel { // classe imóvel //
    private $noimovel;
    private $endereco;
    private $valor;
    private $valorcomissao;

    function getnoimovel() {
        return $this->noimovel;
    }
    
    function getendereco() {
        return $this->endereco;
    }
    
    function getvalor() {
        return $this->valor;
    }
    
    function getvalorcomissao() {
        return $this->valorcomissao;
    }
    
    
    function setnoimovel($noimovel) {
        $this->noimovel = $noimovel;
    }
    
    function setendereco($endereco) {
        $this->endereco = $endereco;
    }   
    
    function setvalor($valor) {
        $this->valor = $valor;
    }
    
    function setvalorcomissao($valorcomissao) {
        $this->valorcomissao = $valorcomissao;
    }
    

    function __construct($noimovel = null, $valor = null, $endereco = null, $valorcomissao = null) {
        $this->noimovel = $noimovel;
        $this->valor = $valor;
        $this->endereco = $endereco;
        $this->valorcomissao = $valorcomissao;
    }
    
    public function lista(){ // método para listar dado de imóveis //
        try {
            $sql  = "SELECT noimovel, valor, endereco, valorcomissao FROM tbvenda ORDER BY noimovel";
            $conn = ConexaoBD::conecta();
            $sql  = $conn->query($sql);
            $res = array();
            while($row = $sql->fetch(PDO::FETCH_OBJ)) {
                $imovel = new imovel();
                $imovel->setnoimovel($row->noimovel);
                $imovel->setvalor($row->valor);
                $imovel->setendereco($row->endereco);
                $imovel->setvalorcomissao($row->valorcomissao);
                $res[] = $imovel;
            }
            return $res;
        } catch (Exception $e) {
             echo "ERRO: ".$e->getMessage()."<br><br>";
        }
    }
    
   public function consulta($id){ //método para consulta de imóvel //
        try {
            $sql  = "SELECT noimovel, endereco FROM tbvenda WHERE noimovel=".$id." ORDER BY noimovel";
            $conn = ConexaoBD::conecta();
            $sql  = $conn->query($sql);

            $res = array();
            while($row = $sql->fetch(PDO::FETCH_OBJ)) {
                $imovel = new imovel();
                $imovel->setnoimovel($row->noimovel);
                $imovel->setendereco($row->endereco);

                $res[] = $imovel;
            }
            return $res;
        } catch (Exception $e) {
             return "ERRO: ".$e->getMessage()."<br><br>";
        }
    }
}