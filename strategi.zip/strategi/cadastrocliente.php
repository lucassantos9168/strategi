<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title> Stramoveis </title> <!-- título -->
    <meta charset="utf-8"> <!-- codificação de caracteres -->
    <link rel="stylesheet" type="text/css" href="assets/css/estilo.css" media="screen" /> <!-- link para  arquivo css -->
    <link rel="icon" href="assets/imagens/favicon.ico"> <!-- ícone da página -->
    <link rel="preconnect" href="https://fonts.googleapis.com"> <!-- link para importação de fonte externa -->
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> <!-- link para importação de fonte externa -->
    <link href="https://fonts.googleapis.com/css2?family=Courgette&display=swap" rel="stylesheet"> <!-- link para importação de fonte externa -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet"> <!-- link para importação de fonte externa -->
  </head>
  <body style="height: 0px;">
   
    <div class="box">
      
      <div class="area">
        Cadastro de clientes
      </div> <br>

      <img src="assets/imagens/adicionar.png"> <br> <br> <br>

      <form action="" method="post">
        <input type="text" placeholder="Nome" id="name" name="nome" required="" pattern="[a-zA-Záãâéêíîóôõú\s]+$">
        <input type="text" placeholder="CPF (ex: 000.000.000-00)" id="cpf" name="cpf" required="" pattern="\d{3}\.\d{3}\.\d{3}-\d{2}">
        <input type="text" placeholder="E-mail" id="email" name="email" required="" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$">
        <input type="text" placeholder="Telefone (ex: (xx) xxxxx-xxxx)" id="tel" name="tel" required="" pattern="\([0-9]{2}\)[\s][0-9]{5}-[0-9]{4}"> <br> <br>
        <button type="submit" name="cadastrar" id="cadastrar"> Cadastrar </button> <br>
            
        <?php include('bd/cliente.php'); ?>
        <?php
            if (isset($_POST['cadastrar'])) {
                $nome   = $_POST['nome'];
                $cpf   = $_POST['cpf'];
                $email   = $_POST['email'];
                $tel   = $_POST['tel'];

                $link = mysqli_connect("localhost","root","","dbstramoveis");
                
                $f = new cliente();
                $f->insere($nome, $cpf, $email, $tel);
                header ("location: gerenciamentocliente.php");
                }
        ?>
      </form>

      <a href="gerenciamentocliente.php"> <button> Voltar </button>  </a>
      
    </div>

  </body>
</html>