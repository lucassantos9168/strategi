<?php  include('cliente.php'); ?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php include('bd/cliente.php'); ?>
        <?php
            if (isset($_GET['excluir'])) { // exclui o cliente //
                $id = $_GET['excluir'];
            
                $f = new cliente();
                $resp = $f->exclui($id);

                header('location: gerenciamentocliente.php');
            }
        ?>
    </body>
</html>