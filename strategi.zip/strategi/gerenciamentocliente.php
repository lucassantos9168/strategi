<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title> Stramoveis </title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="assets/css/estilo.css" media="screen" />
    <link rel="icon" href="assets/imagens/favicon.ico">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Courgette&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
  </head>
  <body>
   
    <div class="lst">
      <div class="area" style="font-size: 32px">
        Gerenciamento de cliente
      </div> <br>
      
      <img src="assets/imagens/cliente.png"> <br> <br> <br>
      
      
      <table>  <!-- tabela com dados dos clientes -->
          
            <th> Nome </th>
            <th> CPF </th>
            <th> E-mail </th>
            <th> Telefone </th>
            <?php include('bd/cliente.php'); ?>
            <?php 
                $f = new cliente(); 
                $lista_cliente = $f->lista();
                foreach($lista_cliente as $lst_cliente) { ?> <!-- foreach com lista para os dados -->
                <tr>
                    <td>
                        <?php echo $lst_cliente->getnome(); ?>
                    </td> 
                    <td>
                        <?php echo $lst_cliente->getcpf() ?>
                    </td>
                    <td>
                        <?php echo $lst_cliente->getemail() ?>
                    </td>
                    <td>
                        <?php echo $lst_cliente->gettel() ?>
                    </td>
                    <td>
                        <a href="alterar.php?editar=<?php echo $lst_cliente->getcpf(); ?>" style="background-color: transparent"> <img src="assets/imagens/alterar.png"> </a> <!-- link para alteraração dados -->
                    </td>
                    <td>
                        <a href="excluir.php?excluir=<?php echo $lst_cliente->getcpf(); ?>" style="background-color: transparent"> <img src="assets/imagens/apagar.png"> </a <!-- exclusão de cliente -->
                        <br>
                    </td>
                </tr>
            <?php }?>
          
      </table>
           
      <br>
      <a href="cadastrocliente.php"> <button> Cadastrar cliente </button> </a> <br> <br>
      <a href="selecao.php"> <button> Voltar </button> </a>

      
    </div>

  </body>
</html>