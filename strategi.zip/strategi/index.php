<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title> Stramoveis </title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="assets/css/estilo.css" media="screen" />
    <link rel="icon" href="assets/imagens/favicon.ico">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Courgette&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
  </head>
  <body style="height: 0px;">
   
    <div class="box">
      <div class="area">
        Login
      </div> <br>
      <img src="assets/imagens/apartamento.png"> <br> <br> <br>

      <form action="" method="post"> <!-- formulario de login -->
        <input type="text" placeholder="Login" id="usuario" name="usuario" required=""> <br>
        <input type="text" placeholder="Senha" id="senha" name="senha" required=""> <br> <br>
        <button name="login" type="submit" onclick="capturausuario()")> Fazer login </button> 
      </form>
      
        <?php // verifica se usuário e senha existem no banco //
            include_once('bd/conexao.php');
            if (isset($_POST['login'])) {
                $conn = ConexaoBD::conecta();

                $usuario = $_POST['usuario']; // coleta valor do input "usuario" //
                $senha = $_POST['senha']; // coleta valor do input "senha" //
                
                $link = mysqli_connect("localhost","root","","dbstramoveis"); // conexão com banco //
                
                $verifica_usuario_senha = mysqli_query ($link, "SELECT * FROM tbcorretor WHERE usuario = '$usuario' AND senha = '$senha'");
                
                if(mysqli_num_rows($verifica_usuario_senha) == 1){  // se a senha e usuário existirem no banco o site avança para a próxima página //  
                            header ("location: selecao.php");
                        }

                        else{ // mensagem caso usuário ou senha não existam no banco //
                            echo '<br> <a style="font-size: 12px; font-family: Verdana, Geneva, Tahoma, sans-serif; color: red; font-weight: bold"> Login ou senha incorretos! <a>';
                        }
            }
        ?>
      
      
    </div>

  </body>
</html>