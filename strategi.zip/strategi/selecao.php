<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title> Stramoveis </title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="assets/css/estilo.css" media="screen" />
    <link rel="icon" href="assets/imagens/favicon.ico">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Courgette&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
  </head>
  <body> <!-- página de escolha de ação -->
    
    <div class="box">
        
        <div class="area">
          Gerenciamento de clientes ou Vendas
        </div> <br>
        
        <div class="cards">
            <a href="gerenciamentocliente.php"><img src="assets/imagens/cliente.png"></a>
            <a href="vendas.php"><img src="assets/imagens/venda.png"></a>
        </div>

        <a href="index.php"> <button> Voltar para login </button> </a>
    </div>

  </body>
</html>