<!DOCTYPE html>
<html lang="pt-br" style="height: 0px">
  <head>
    <title> Stramoveis </title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="assets/css/estilo.css" media="screen" />
    <link rel="icon" href="assets/imagens/favicon.ico">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Courgette&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
  </head>
  <body>
   
    <div class="box">
      
      <div class="area">
        Simulação
      </div> <br>
      
      <img src="assets/imagens/dinheiro.png"> <br> <br> <br>
      
      <?php  include('bd/imovel.php'); ?> <!-- mostra os dados do imóvel selecionado -->
      <?php
        if (isset($_GET['simular'])) {
            $id = $_GET['simular'];

            $f = new imovel();
            $imovel = $f->consulta($id);

        }
      ?>
      
      <fieldset style="color: black; font-size: 18px"> <?php echo $id ?>
          <legend> Dados do imóvel </legend>
      </fieldset>
      
      <a href="vendas.php"> <button> Voltar </button> </a>

      
    </div>

  </body>
</html>