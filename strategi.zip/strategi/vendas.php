<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title> Stramoveis </title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="assets/css/estilo.css" media="screen" />
    <link rel="icon" href="assets/imagens/favicon.ico">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Courgette&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
  </head>
  <body>
   
      <div class="lst">
      <div class="area" style="font-size: 32px">
        Vendas
      </div> <br>
      
      <img src="assets/imagens/venda.png"> <br> <br> <br>
      
      <fieldset>  
        <legend>⠀Cliente⠀</legend>
        <select name="cliente" id="cliente"> <!-- select com o nome dos clientes -->
             <?php include('bd/cliente.php'); ?> 
             <?php 
                $f = new Cliente();
                $lista_cliente = $f->lista();

                foreach($lista_cliente as $lst_cliente) { ?>

                <option> <?php echo $lst_cliente->getnome(); ?>
                </option> <?php } ?>
        </select>
      </fieldset> <br>

      <fieldset>  
        <legend>⠀Pagamento⠀</legend>
        <select name="condicao" id="condicao"> 
            <option value="À vista">⠀À vista </option>
            <option value="180 parcelas">⠀Em 180 vezes </option>
        </select>
      </fieldset> <br> <br>
      
      <table> <!-- tabela com dados dos imóveis cadastrados -->
          
            <th> Imóvel </th>
            <th> Endereço </th>
            <th> Valor (R$) </th>
            <th> Valor de comissão (R$) </th>
            <?php include('bd/imovel.php'); ?>
            <?php 
                $f = new imovel(); 
                $lista_imovel = $f->lista();
                foreach($lista_imovel as $lst_imovel) { ?>
                <tr>
                    <td>
                        <?php echo $lst_imovel->getnoimovel(); ?>
                    </td> 
                    <td>
                        <?php echo $lst_imovel->getendereco() ?>
                    </td>
                    <td>
                        <?php echo $lst_imovel->getvalor() ?>
                    </td>
                    <td>
                        <?php echo $lst_imovel->getvalorcomissao() ?>
                    </td>
                    <td>
                        <a href="simulacao.php?simular=<br>Nome: <?php echo $lst_imovel->getnoimovel(); ?> <br> <br> Endereço: <?php echo $lst_imovel->getendereco(); ?> <br> <br> Valor: R$ <?php echo $lst_imovel->getvalor(); ?> <br> <br> Valor de comissão: R$ <?php echo $lst_imovel->getvalorcomissao(); ?> <br> <br>"> Simular </a> <!-- link para página de resumo -->
                    </td>
                    
                </tr>
            <?php }?>
          
      </table>
      
      <br>
      <a href="selecao.php"> <button> Voltar </button> </a>

    </div>

  </body>
</html>